
import { Router } from './app/core/router.js';
window.onload = () => Router.init(document.getElementById('app'));
