
export class StatefulWidget {
  constructor() {
    this.state = {};
    this.element = null;
  }

  setState(update) {
    this.state = { ...this.state, ...update };
    this.update();
  }

  create() {}
  render() { return ''; }

  mount(el) {
    this.element = el;
    this.create();
    this.update();
  }

  update() {
    if (this.element)
      this.element.innerHTML = this.render();
  }
}
