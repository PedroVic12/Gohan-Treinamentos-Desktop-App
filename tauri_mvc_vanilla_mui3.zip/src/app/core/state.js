
export const State = {
  data: JSON.parse(localStorage.getItem('app_state') || '{}'),
  listeners: [],

  set(key, val) {
    this.data[key] = val;
    localStorage.setItem('app_state', JSON.stringify(this.data));
    this.listeners.forEach(cb => cb(this.data));
  },

  get(key) { return this.data[key]; },

  subscribe(cb) { this.listeners.push(cb); }
};
