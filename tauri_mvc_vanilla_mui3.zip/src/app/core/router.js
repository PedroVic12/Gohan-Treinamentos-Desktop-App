
import { HomePage } from '../pages/home_page.js';
import { SettingsPage } from '../pages/settings_page.js';

export const Router = {
  mountPoint: null,

  pages: {
    home: HomePage,
    settings: SettingsPage,
  },

  init(root) {
    this.mountPoint = root;
    this.go('home');
  },

  go(pageName) {
    const PageClass = this.pages[pageName];
    const page = new PageClass();
    page.mount(this.mountPoint);
  }
};
