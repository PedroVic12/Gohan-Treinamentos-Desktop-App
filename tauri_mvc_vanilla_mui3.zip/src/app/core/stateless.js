
export class StatelessWidget {
  constructor(props = {}) {
    this.props = props;
  }

  render() { return ''; }
}
