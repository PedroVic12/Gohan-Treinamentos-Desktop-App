
import { StatelessWidget } from '../core/stateless.js';

export class GlassCard extends StatelessWidget {
  render() {
    return `<div class='glass-card'>${this.props.content}</div>`;
  }
}
