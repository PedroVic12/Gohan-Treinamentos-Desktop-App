
import { StatefulWidget } from '../core/stateful.js';
import { Router } from '../core/router.js';
import { State } from '../core/state.js';

export class SettingsPage extends StatefulWidget {
  create() {
    this.state = {
      username: State.get('username') || ''
    };
  }

  save() {
    const val = document.getElementById('username').value;
    State.set('username', val);
    this.setState({ username: val });
  }

  render() {
    return `
      <div class="mui-container">
        <h1>Configurações</h1>

        <div class="mui-textfield">
          <input id='username' value="${this.state.username}" placeholder="Nome de usuário">
        </div>

        <button class='mui-btn mui-btn--primary' id='save'>Salvar</button>
        <button class='mui-btn mui-btn--danger' id='back'>Voltar</button>
      </div>
    `;
  }

  update() {
    super.update();
    document.getElementById('save')?.addEventListener('click', () => this.save());
    document.getElementById('back')?.addEventListener('click', () => Router.go('home'));
  }
}
