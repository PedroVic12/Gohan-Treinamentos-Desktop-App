
import { StatefulWidget } from '../core/stateful.js';
import { Router } from '../core/router.js';
import { State } from '../core/state.js';
import { GlassCard } from '../components/glass_card.js';

export class HomePage extends StatefulWidget {
  create() {
    this.state = { count: State.get('count') || 0 };
  }

  increment() {
    const newVal = this.state.count + 1;
    this.setState({ count: newVal });
    State.set('count', newVal);
  }

  render() {
    return `
      <div class="mui-container">
        <h1>Home Page</h1>

        ${new GlassCard({ content: `Contador: ${this.state.count}` }).render()}

        <button class='mui-btn mui-btn--primary' id='inc'>Incrementar</button>
        <button class='mui-btn mui-btn--accent' id='settings'>Configurações</button>
      </div>
    `;
  }

  update() {
    super.update();
    document.getElementById('inc')?.addEventListener('click', () => this.increment());
    document.getElementById('settings')?.addEventListener('click', () => Router.go('settings'));
  }
}
